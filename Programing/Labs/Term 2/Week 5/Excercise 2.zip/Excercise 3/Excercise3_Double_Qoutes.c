# include <stdio.h>
# include <stdlib.h>
# include <Windows.h>
main()
{
    //Program to read in and display string with specific characters with and without null character and display each version
    char my_word[] = "Hello World";
    
    printf("%s", my_word); 
    
    Sleep(150000);
}